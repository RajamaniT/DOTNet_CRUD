﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace webapi
{
    [DataContract]
    public class Module
    {
        [DataMember]
        public int moduleId { get; set; }

        [DataMember]
        public string modulename { get; set; }
    }
}
