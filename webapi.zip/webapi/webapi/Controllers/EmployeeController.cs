﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using webapi.Contract;
using webapi.Entities;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace webapi.Controllers
{
    [Route("api/Employee")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {

        private readonly IEmployeeInterface EmployeeService;
        public EmployeeController(IEmployeeInterface employeeService)
        {
            EmployeeService = employeeService;
        }

        [EnableCors]
        [HttpGet]
        [Route("GetEmployeeDetail")]       
        public IEnumerable<Employee> GetEmployeeDetail()
        {
            var list = EmployeeService.GetEmployeeDetail();
            //return ConvertToTankReadings(resultTable);
            return list;
        }


    }
}
