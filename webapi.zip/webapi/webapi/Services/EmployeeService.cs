﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using webapi.Contract;
using webapi.Entities;
using webapi.Entities.Procedure;
using webapi.Infrastructure;

namespace webapi.Services
{
    public class EmployeeService: IEmployeeInterface
    {
        private readonly IRepository<Employee> EmployeeRepository;
        public EmployeeService(IRepository<Employee> repository)
        {
            EmployeeRepository = repository;
        }
        public IEnumerable<Employee> GetEmployeeDetail()
        {
            var procedureGetCMS = new GetEmployeeDetail()
            {
            };
            var allemployee = EmployeeRepository.ExecuteStoredProcedure<Employee>(procedureGetCMS);
            IEnumerable<Employee> emplist = allemployee.Select(a => new Employee
            {
                Id = a.Id,
                Name = a.Name,
                EmailId = a.EmailId,
                Designation = a.Designation,
                IsActive = a.IsActive
            }).ToList();

            //var listemployee = new List<Employee>();

            //var employees = EmployeeRepository.GetMany(x=> (bool)x.IsActive);
            //if(employees != null && employees.Count() > 0)
            //{                
            //    foreach (var item in employees)
            //    {
            //        var employee = new Employee()
            //        {
            //            Id = item.Id,
            //            Name = item.Name,
            //            Designation = item.Designation,
            //            IsActive = item.IsActive,
            //        };
            //        listemployee.Add(employee);
            //    }
            //}
            //return listemployee;

            return emplist;

            //string connection = "data source=dealerportal.ctzt1q0dkfdj.us-east-1.rds.amazonaws.com;initial catalog=Mops_Test;user id=dealerportal;password=8EaxpGeXR9DN;persist security info=True;integrated security=False;MultipleActiveResultSets=True;App=EntityFramework";
            //var resultTable = new DataTable();

            //using (var conn = new SqlConnection(connection))
            //{
            //    var sql = "SELECT ID, Name from core.Module ";
            //    using (var cmd = new SqlCommand(sql, conn))
            //    {
            //        using (var adapter = new SqlDataAdapter(cmd))
            //        {

            //            adapter.Fill(resultTable);
            //        }
            //    }
            //}
            //return ConvertToTankReadings(resultTable);

        }

        //private IEnumerable<Module> ConvertToTankReadings(DataTable dataTable)
        //{
        //    return dataTable.AsEnumerable().Select(row => new Module
        //    {

        //        moduleId = Convert.ToInt32(row["ID"]),
        //        modulename = row["Name"].ToString(),

        //    });
        //}
    }
}
