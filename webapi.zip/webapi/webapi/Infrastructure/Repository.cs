﻿using EntityFrameworkExtras.EF7;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using webapi.Entities;

namespace webapi.Infrastructure
{
    public class Repository<T> : IRepository<T> where T : class
    {
        private EmployeeContext dataContext;
        private readonly DbSet<T> dbset;
        public Repository(IDatabaseFactory databaseFactory)
        {
            DatabaseFactory = databaseFactory;
            dbset = DataContext.Set<T>();
            dataContext.Database.SetCommandTimeout(int.MaxValue);
        }
        public IDatabaseFactory DatabaseFactory
        {
            get;
            private set;
        }
        public EmployeeContext DataContext
        {
            get { return dataContext ?? (dataContext = DatabaseFactory.Get()); }
        }
        public virtual void Add(T entity)
        {
            dbset.Add(entity);
        }
        public virtual void Update(T entity)
        {
            dbset.Attach(entity);
            dataContext.Entry(entity).State = EntityState.Modified;

        }
        public virtual void Delete(T entity)
        {
            dbset.Remove(entity);
        }
        public virtual void Delete(Expression<Func<T, bool>> where)
        {
            IEnumerable<T> objects = dbset.Where<T>(where).AsEnumerable();
            foreach (T obj in objects)
                dbset.Remove(obj);
        }
        public virtual T GetById(long id)
        {
            return dbset.Find(id);
        }
        public virtual T GetById(string id)
        {
            return dbset.Find(id);
        }
        public virtual IEnumerable<T> GetAll()
        {
            return dbset.ToList();
        }
        public virtual IEnumerable<T> GetMany(Expression<Func<T, bool>> where)
        {
            return dbset.Where(where).ToList();
        }
        public T Get(Expression<Func<T, bool>> where)
        {
            return dbset.Where(where).FirstOrDefault<T>();
        }
        public virtual IEnumerable<T> ExecWithStoreProcedure(string query, params object[] parameters)
        {
            //dataContext.Database.SetCommandTimeout(int.MaxValue); 
            return dataContext.Set<T>().FromSqlRaw(query, parameters).ToList();

        }

        //public virtual IEnumerable<T> ExecWithStoreProcedure(string query)
        //{
        //    dataContext.Database.SetCommandTimeout(int.MaxValue);
        //    return dataContext.Set<T>().FromSql("Exec " + query).ToList();
        //}

        public virtual IEnumerable<T> ExecuteStoredProcedure<T>(object Procedure)
        {
            //dataContext.Database.SetCommandTimeout(int.MaxValue);
            return dataContext.Database.ExecuteStoredProcedure<T>(Procedure);
        }

        public T Get(Expression<Func<T, bool>> where, string includeTable)
        {
            return dbset.Include(includeTable).Where(where).FirstOrDefault<T>();
        }

        public IEnumerable<T> GetMany(Expression<Func<T, bool>> where, string includeTable)
        {
            return dbset.Include(includeTable).Where(where).ToList();
        }

        //public IQueryable<T> GetGrid(Expression<Func<T, bool>> where)
        //{
        //    return dbset.Where(where);
        //}
    }
}
