﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using webapi.Entities;

namespace webapi.Infrastructure
{
    public class DatabaseFactory : Disposable, IDatabaseFactory
    {
        private EmployeeContext dataContext;

        public DatabaseFactory(EmployeeContext context)
        {
            dataContext = context;
        }

        public EmployeeContext Get() => dataContext;
        protected override void DisposeCore()
        {
            if (dataContext != null)
            {
                dataContext.Dispose();
                dataContext = null;
            }
        }
    }
}
