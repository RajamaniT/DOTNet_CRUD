﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using webapi.Entities;

namespace webapi.Infrastructure
{
    public interface IDatabaseFactory : IDisposable
    {
        EmployeeContext Get();
    }
}
