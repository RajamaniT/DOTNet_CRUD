﻿using System;
using System.Collections.Generic;

#nullable disable

namespace webapi.Entities
{
    public partial class Testdb
    {
        public string CustomerName { get; set; }
        public string ContactName { get; set; }
        public string Address { get; set; }
    }
}
