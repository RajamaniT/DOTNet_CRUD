﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace webapi.Entities
{
    public partial class EmployeeContext : DbContext
    {
        public EmployeeContext()
        {
        }

        public EmployeeContext(DbContextOptions<EmployeeContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Employee> Employees { get; set; }
        public virtual DbSet<Sample123> Sample123s { get; set; }
        public virtual DbSet<Testdb> Testdbs { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=sma.ctzt1q0dkfdj.us-east-1.rds.amazonaws.com;Database=testdb;Trusted_Connection=True;user id=dealerportalsma;password=ejadmin123;persist security info=True;integrated security=False;MultipleActiveResultSets=True;App=EntityFramework");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Employee>(entity =>
            {
                entity.ToTable("Employee");

                entity.HasIndex(e => e.EmailId, "UQ__Employee__7ED91ACE0525BBEC")
                    .IsUnique();

                entity.Property(e => e.CreatedOn).HasColumnType("datetime");

                entity.Property(e => e.Designation).HasMaxLength(300);

                entity.Property(e => e.EmailId).HasMaxLength(400);

                entity.Property(e => e.Name).HasMaxLength(300);
            });

            modelBuilder.Entity<Sample123>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("sample123");

                entity.Property(e => e.Char)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("char");

                entity.Property(e => e.No).HasColumnName("NO");
            });

            modelBuilder.Entity<Testdb>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("testdb");

                entity.Property(e => e.Address)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ContactName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CustomerName)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
