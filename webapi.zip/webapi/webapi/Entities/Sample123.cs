﻿using System;
using System.Collections.Generic;

#nullable disable

namespace webapi.Entities
{
    public partial class Sample123
    {
        public int? No { get; set; }
        public string Char { get; set; }
    }
}
